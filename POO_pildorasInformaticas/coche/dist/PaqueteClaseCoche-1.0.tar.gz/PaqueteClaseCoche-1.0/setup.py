from setuptools import setup

setup(
    name= 'PaqueteClaseCoche',
    version='1.0',
    description='Paquetes para usar la clase coche',
    author='Santiago',
    author_email='saruizt@unal.edu.co',
    packages=['paquetesCoche']
)

