from setuptools import setup

setup(

    name= "PaqueteClaseUsuario",
    version="1.0",
    description="Paquete para usar la clase Usuario",
    author= "Santiago",
    author_email="saruizt@unal.edu.co",
    packages=["paquetesUsuario"]
)